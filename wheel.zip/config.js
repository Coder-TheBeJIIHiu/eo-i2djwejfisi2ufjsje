const groupToken 	= '5ca420c494ffad09f0aca72d35bca5ff974f35ccd54e4a412527ba8f987d81955b833ab34fa81c55dad79';
const groupID 	 	= 210703152
const urlDB = 'mongodb+srv://coinwheel:oper4545@cluster0.hwz2s.mongodb.net/wheel?retryWrites=true&w=majority'; //ссылна на базу данных
const nameDB = 'wheel' // база данных

module.exports = {
  groupToken,
  groupID,

  urlDB,
  nameDB
};